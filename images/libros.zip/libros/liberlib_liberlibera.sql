-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 29, 2018 at 09:54 PM
-- Server version: 5.6.41
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `liberlib_liberlibera`
--

-- --------------------------------------------------------

--
-- Table structure for table `autor`
--

CREATE TABLE `autor` (
  `Id_autor` int(11) NOT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `Nacionalidad` varchar(255) DEFAULT NULL,
  `Nacimiento` date DEFAULT NULL,
  `Muerte` date DEFAULT NULL,
  `Sexo` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autor`
--

INSERT INTO `autor` (`Id_autor`, `Nombre`, `Nacionalidad`, `Nacimiento`, `Muerte`, `Sexo`) VALUES
(1, 'Miguel de Cervantes Saavedra', 'España', '1547-09-29', '1616-04-22', 1),
(2, 'Thomas Mann', 'Alemania', '1875-06-06', '1955-08-12', 1),
(3, 'Robert Louis Stevenson', 'Escocia', '1850-11-13', '1894-12-03', 1),
(4, 'Benito Pérez Galdós', 'España', '1843-05-10', '1920-01-04', 1),
(5, 'Santa Teresa de Jesús', 'España', '1515-03-28', '1582-11-04', 0),
(6, 'Homero ', 'Grecia Antigua', '1014-08-17', '1085-10-03', 1),
(7, 'John Green', 'EUA', '1977-08-24', '0000-00-00', 1),
(8, 'Cornell Woolrich', 'EUA', '1903-12-04', '1968-10-25', 1),
(9, 'Carlos Cuauhtémoc Sánchez', 'México', '1964-04-13', '0000-00-00', 1),
(10, 'Tonya Hurley', 'EUA', '0000-00-00', '0000-00-00', 0),
(11, 'Robert Fisher', 'EUA', '1922-09-21', '2008-09-26', 1),
(12, 'Isabel Allende Llona', 'Chile - EUA', '1942-08-02', '0000-00-00', 0),
(13, 'Edmundo De Amicis', 'Italia', '1846-10-21', '1908-03-11', 1),
(35, 'Nicolás Maquiavelo', 'Italia', '1469-05-03', '1527-06-21', 1),
(14, 'Gabriel García Márquez', 'Colombia', '1927-03-06', '2014-04-17', 1),
(15, 'Óscar Wilde', 'Irlanda', '1854-10-16', '1900-11-30', 1),
(16, 'Julio Verne', 'Francia', '1828-02-08', '1905-03-24', 1),
(36, 'Mario Benedetti', 'Uruguay', '1920-09-14', '2009-05-17', 1),
(17, 'Paulo Coelho', 'Brasil', '1947-08-24', '0000-00-00', 1),
(37, 'Antoine de Saint-Exupéry', 'Francia', '1900-06-29', '1944-07-31', 1),
(18, 'Aldous Huxley', 'Inglaterra', '1894-07-26', '1963-11-22', 1),
(19, 'Suzanne Collins', 'EUA', '1964-08-10', '0000-00-00', 0),
(39, 'Gerald Di pego', 'EUA', '1941-07-22', '0000-00-00', 1),
(20, 'Verónica Anne Roth', 'EUA', '1988-08-19', '0000-00-00', 0),
(21, 'Stephen King', 'EUA', '1947-09-21', '0000-00-00', 1),
(22, 'Sara Sefchovich Wasongarz', 'México', '1949-04-02', '0000-00-00', 0),
(40, 'Julio Cortazar', 'Bélgica', '1914-08-26', '1914-02-12', 1),
(23, 'Erika Leonard Mitchell', 'Inglaterra', '1963-03-07', '0000-00-00', 0),
(24, 'Antonio Malpica Maury', 'México', '1967-03-08', '0000-00-00', 1),
(25, 'Manú Dornbierer', 'México', '1932-12-20', '0000-00-00', 0),
(26, 'Stefan Zweig', 'Austria - Hungría', '1881-11-28', '1942-02-22', 1),
(27, 'Vladímir Ilich Uliánov', 'Rusia', '1870-04-22', '1924-01-21', 1),
(28, 'Alejandro Dumas', 'Francia', '1802-07-24', '1870-12-05', 1),
(29, 'Emma Godoy', 'México', '1918-03-25', '1989-07-30', 0),
(30, 'Javier García Sánchez', 'España', '1955-04-07', '0000-00-00', 1),
(31, 'Bram Stoker', 'Irlanda', '1847-11-08', '1912-04-20', 1),
(32, 'Herbert George Wells', 'Inglaterra', '1866-09-21', '1946-08-13', 1),
(33, 'Isaac Asimov', 'Rusia', '1920-01-02', '1992-04-06', 1),
(34, 'Jorge Ricardo Isaacs Ferrer', 'Colombia', '1837-04-01', '1895-04-17', 1),
(71, 'Augustine Og Mandino', 'EUA', '1923-12-12', '1996-09-03', 1),
(72, 'William Golding', 'Inglaterra', '1911-09-19', '1993-06-19', 1),
(73, 'Juan Rulfo', 'México', '1917-05-16', '1986-01-07', 1),
(74, 'José Antonio del Cañizo', 'España', '1938-01-05', '0000-00-00', 1),
(42, 'William Shakespeare', 'Inglaterra', '1564-04-26', '1616-05-23', 1),
(43, 'Heinrich Von Kleist', 'Alemania', '1777-12-18', '1811-11-21', 1),
(75, 'Tomás Moro', 'Reino Unido', '1478-02-07', '1535-06-06', 1),
(76, 'Carlos Fuentes', 'Panamá', '1928-11-11', '2012-05-15', 1),
(44, 'Nicole Bacharan', 'Francia', '1955-01-25', '0000-00-00', 0),
(77, 'Fernando de Rojas', 'España', '0000-00-00', '1541-04-03', 1),
(78, 'Florencia Scovel Shinn ', 'EUA', '1871-09-24', '1940-11-17', 0),
(45, 'Thomas Thompson', 'EUA', '9033-10-03', '1982-10-29', 1),
(79, 'León Rodrigo Krauze Turrent', 'México', '1975-01-04', '0000-00-00', 1),
(80, 'Federico García Lorca', 'España', '1898-06-05', '1936-08-18', 1),
(46, 'Alan Furst', 'EUA', '1941-02-20', '0000-00-00', 1),
(81, 'Arthur Schopenhauer', 'Alemania', '1788-02-22', '1860-09-21', 1),
(47, 'Abilo Estévez', 'España', '1954-01-09', '0000-00-00', 1),
(82, 'Thomas Connellan', 'EUA', '0000-00-00', '0000-00-00', 1),
(48, 'Susan Fordward', 'EUA', '1938-05-14', '0000-00-00', 0),
(83, 'Borís Pasternak', 'Rusia', '1890-02-10', '1960-05-30', 1),
(84, 'Maurice Joly', 'Francia', '1829-09-22', '1878-07-15', 1),
(85, 'Howard Phillips Lovecraft', 'EUA', '1890-08-20', '1937-03-15', 1),
(49, 'Mark Twain', 'EUA', '1835-11-30', '1910-04-21', 1),
(86, 'Narciso Genovese', 'Italia', '0000-00-00', '0000-00-00', 1),
(87, 'Ernest Hemingway', 'EUA', '1899-07-21', '1961-07-02', 1),
(51, 'Mary W. Shelley', 'Inglaterra', '1797-08-30', '1851-02-01', 0),
(88, 'Elsa Rodríguez Tadeo', 'México', '0000-00-00', '0000-00-00', 0),
(89, 'Louisa May Alcott', 'EUA', '1832-11-29', '1888-03-06', 0),
(52, 'Platón', 'Grecia', '0427-05-07', '0000-00-00', 1),
(90, 'Selma Ottilia Lovisa Lagerlöf', 'Suecia', '1858-11-20', '1940-03-16', 0),
(91, 'Robert Lawrence Stine', 'EUA', '1943-10-08', '0000-00-00', 1),
(53, 'Joan Martínez Alier', 'España', '0000-00-00', '0000-00-00', 1),
(92, 'Agustín Escobar Ledesma', 'México', '0000-00-00', '0000-00-00', 1),
(54, 'Jack London', 'EUA', '1876-01-12', '1916-11-22', 1),
(93, 'Franck Pavloff', 'Francia', '1940-04-24', '0000-00-00', 1),
(94, 'Nicola Bardola', 'Suiza', '1959-04-27', '0000-00-00', 1),
(56, 'Stephenie Meyer', 'EUA', '1973-12-24', '0000-00-00', 0),
(57, 'Rubén Darío', 'Nicaragüa', '1867-01-18', '1916-02-06', 1),
(95, 'Georges Ata', 'Inglaterra', '0000-00-00', '0000-00-00', 1),
(96, 'Jomi García Ascot', 'Túnez', '1927-08-13', '1986-08-14', 1),
(58, 'Hermann Hesse', 'Alemania', '1877-07-02', '1962-08-09', 1),
(97, 'Daniel Defoe', 'Inglaterra', '1660-10-10', '1731-05-05', 1),
(98, 'Andrew Matthews', 'Galés', '1948-10-26', '0000-00-00', 1),
(60, 'Gabriel Bauducco', 'México', '1972-02-19', '0000-00-00', 1),
(99, 'Franz Kafka ', 'Austria - Hungría', '1883-07-03', '1924-06-03', 1),
(61, 'Wayne Dyer', 'EUA', '1940-05-10', '2015-08-29', 1),
(100, 'Macario Schettino', 'México', '1963-08-29', '0000-00-00', 1),
(101, 'Edgar Allan Poe', 'EUA', '1809-01-19', '1849-10-07', 1),
(62, 'José Joaquín Fernández de Lizardi', 'México', '1776-11-15', '1827-06-21', 1),
(102, 'Hermann Melville', 'EUA', '1819-08-01', '1891-09-28', 1),
(63, 'Gerald G. Jampolsky', 'EUA', '1925-02-11', '0000-00-00', 1),
(103, 'Deepak Chopra', 'India', '1946-10-22', '0000-00-00', 1),
(104, 'Ignacio Manuel Altamirano', 'México', '1834-11-13', '1893-02-13', 1),
(65, 'Kristiane ', 'Alemania', '1965-12-13', '0000-00-00', 0),
(105, 'Robert Silverberg', 'EUA', '1835-01-15', '0000-00-00', 1),
(66, 'Louis Fischer', 'EUA', '1896-02-29', '1970-01-15', 1),
(124, 'Antonio Mediz Bolio', 'México', '1884-10-13', '1957-09-15', 1),
(67, 'Virginia Cleo Andrews', 'EUA', '1923-06-06', '1986-12-19', 0),
(106, 'Paul Auster', 'EUA', '1947-02-03', '0000-00-00', 1),
(108, 'Julius Segal', 'EUA', '1924-12-21', '1994-09-26', 1),
(107, 'Francisco Rojas Gonzáles ', 'México', '1904-03-10', '1951-10-22', 1),
(109, 'Tere de las Casas', 'México', '1991-11-08', '0000-00-00', 0),
(110, 'Briceida Cuevas Cob', 'México', '1969-06-12', '0000-00-00', 1),
(111, 'Ruis(Eduardo del Río)', 'México', '1934-06-20', '2017-08-08', 1),
(112, 'John Ronald Reuel Tolkien', 'Sudáfrica', '1892-01-03', '1973-09-02', 1),
(113, 'Diana Silvia Pérez Loredo', 'Argentina', '0000-00-00', '0000-00-00', 0),
(114, 'Edmond Rostand', 'Francia', '1868-04-01', '1918-12-02', 1),
(115, 'Omar Khayyam', 'Irán', '1048-05-18', '1131-12-04', 1),
(116, 'Victor Hugo', 'Francia', '1802-02-26', '1885-05-22', 1),
(117, 'Cornelia Funke', 'Alemania', '1985-12-10', '0000-00-00', 0),
(118, 'Friedrich Nietzsche', 'Alemania', '1844-10-15', '1900-08-25', 1),
(119, 'Juan Ramón Jiménez', 'España', '1881-12-24', '1958-05-29', 1),
(120, 'Richard Bach', 'EUA', '1936-06-23', '0000-00-00', 1),
(121, 'Gibrán Jalil Gibrán', 'Líbano', '1883-01-06', '1931-04-10', 1),
(122, 'Christine Nöstlinger', 'Austria', '1936-10-13', '2018-06-28', 0),
(123, 'Antonia White', 'Reino Unido', '1899-03-10', '1980-04-10', 0),
(125, 'Horacio Quiroga', 'Uruguay', '1878-12-31', '1937-02-19', 1),
(126, 'Isaac Singer', 'EUA', '1811-10-27', '1875-07-23', 1),
(127, 'Francois Sautereau', 'Francia', '1943-07-20', '2014-09-08', 1),
(128, 'Rusell Baks', 'EUA', '1940-03-28', '0000-00-00', 1),
(129, 'Michael Ende', 'Alemania', '1929-11-12', '1995-08-28', 1),
(130, 'Michael Crichton', 'EUA', '1942-10-23', '2008-11-04', 1),
(64, 'Andrés Garrido del Toral', 'México', '0000-00-00', '0000-00-00', 0),
(68, 'M. Ilin', 'Ucrania', '1896-01-10', '0000-00-00', 1),
(69, 'Lewis Carroll', 'Reino Unido', '1832-01-27', '1898-01-14', 1),
(70, 'Dante Melgar ', 'Perú', '1790-08-10', '1815-05-12', 1),
(59, 'Fresia Castro Moreno', 'Perú', '0000-00-00', '0000-00-00', 0),
(38, 'Martin Westerman', 'EUA', '1964-11-13', '0000-00-00', 1),
(41, 'Juan Tonda Mazón', 'México', '0000-00-00', '0000-00-00', 1),
(50, 'Dorinda Jares Rosendo', '', '0000-00-00', '0000-00-00', 0),
(55, ' Jose Luis Sil ', 'México', '0000-00-00', '0000-00-00', 1),
(131, 'Rhonda Byrne ', 'Australia', '0000-00-00', '0000-00-00', 0),
(132, 'Heinrich Hermann Robert Koch', 'Reino de Hannover', '1843-12-11', '1910-05-27', 1),
(133, 'Joanne Rowling?', 'Reino Unido', '1965-07-31', '0000-00-00', 0),
(134, 'Carson McCullers', 'EUA', '1967-02-19', '1967-08-29', 0),
(135, 'Carlos Trejo', 'México', '0000-00-00', '0000-00-00', 1),
(136, 'Melvin Burgess', 'Inglaterra - Colombia', '1954-04-25', '0000-00-00', 1),
(137, 'Jean-Paul Sartre', 'Francia', '1905-06-21', '1980-04-14', 1),
(138, 'Victoria Avalon', 'EUA', '1949-07-26', '0000-00-00', 0),
(139, 'Todd Burpo', 'EUA', '1968-08-05', '0000-00-00', 1),
(140, 'Rosa McManus Soto', 'México', '0000-00-00', '0000-00-00', 0),
(141, 'Henri Bosco', 'Francia', '1888-11-16', '1976-05-04', 1),
(142, 'Dean R. Koontz ', 'EUA', '1945-07-09', '0000-00-00', 1),
(143, 'Dan Brown', 'EUA', '1964-06-22', '0000-00-00', 1),
(144, 'Walt Whitman', 'EUA', '1819-05-31', '1892-03-26', 1),
(145, 'Sue Jaffarian', 'EUA', '1915-12-21', '0000-00-00', 0),
(146, 'Jaime Homar', 'España', '1974-05-30', '0000-00-00', 1),
(147, 'Mario Vargas Llosa', 'Perú', '1936-03-28', '0000-00-00', 1),
(148, 'Keigo Higashino', 'Japón', '1958-02-04', '0000-00-00', 1),
(149, 'Antonio Fernández Molina', 'España', '0000-00-00', '2005-03-20', 1),
(150, 'Ana María Matute', 'España', '1925-07-26', '2014-06-25', 0),
(151, 'Héctor López Bofill', 'España', '0000-00-00', '0000-00-00', 1),
(152, 'Ron Clements', 'EUA', '1953-04-24', '0000-00-00', 1),
(153, 'George Orwell', ' India', '1903-06-25', '1950-01-21', 1),
(154, 'Denise Linn', 'España', '1950-04-16', '0000-00-00', 0),
(155, 'Richard Paul Evans', 'EUA', '1962-10-11', '0000-00-00', 1),
(156, 'Adrián Recinos', 'Guatemala', '1886-07-05', '1962-03-08', 1),
(157, 'Umberto Eco', 'Italia', '1932-11-05', '2016-02-19', 1),
(158, 'Sidney Sheldon', 'EUA', '1917-02-11', '2007-01-30', 1),
(159, 'Pablo Vierci', 'Uruguay ', '1950-07-07', '0000-00-00', 1),
(160, 'Leopold von Sacher-Masoch', '  Ucrania', '1836-01-17', '1895-05-09', 1),
(161, 'Irving Wallace', 'EUA', '1916-04-19', '1990-06-29', 1),
(162, 'Taylor Caldwell', 'Reino Unido', '1900-07-07', '1985-08-30', 0),
(163, 'John de Abate', 'España', '0000-00-00', '0000-00-00', 1),
(165, 'Claudia Celis', 'Mexico', '1951-04-06', '0000-00-00', 0),
(166, 'Paul Henry de Kruif', 'EUA', '1890-03-02', '1971-02-28', 1),
(167, 'Virginia Axline ', 'EUA', '1911-03-30', '0000-00-00', 0),
(169, 'Dante Alighieri', 'Italia', '1265-05-29', '1321-09-14', 1),
(170, 'Silvia Olmedo', 'España', '1976-05-16', '0000-00-00', 0),
(171, 'Ana Frank', 'Alemania', '1929-06-12', '0000-00-00', 0),
(172, 'Clive Staples Lewis', 'Inglaterra', '1898-11-29', '1963-11-22', 1),
(173, 'Gastón Leroux', 'Francia', '1868-05-06', '1927-04-15', 1),
(174, 'León Tolstói', 'Rusia', '1828-09-09', '1910-11-20', 1),
(175, 'Octavio Paz ', 'México', '1914-03-31', '1998-04-19', 1),
(176, 'Arthur Golden', 'EUA', '1956-12-06', '0000-00-00', 1),
(177, 'Juan José Benítez López', 'España', '1946-09-07', '0000-00-00', 1),
(178, 'Jack Canfield', 'EUA', '1944-08-09', '0000-00-00', 1),
(179, 'George Raymond Richard Martin', 'EUA', '1948-09-20', '0000-00-00', 1),
(180, 'Fray Servando Teresa de Meir', 'México', '1765-10-18', '1827-11-03', 1),
(181, 'Justo Sierra Mèndez', 'México', '1848-01-26', '1912-09-13', 1),
(182, 'Luis Enrique Vega', 'México', '1936-01-02', '0000-00-00', 1),
(183, 'José Saramago', ' Portugal', '1922-11-16', '2010-06-18', 1),
(184, 'Lucie Dufresne', 'Canadá', '1951-01-01', '0000-00-00', 0),
(186, 'Maurice Druon', 'Francia', '1918-04-14', '2009-04-14', 1),
(187, 'Silvia L. Cuesy', 'México', '0000-00-00', '0000-00-00', 0),
(188, 'Ale del Castillo', 'México', '1974-03-16', '0000-00-00', 0),
(189, 'Odin Dupeyron', 'México', '1970-08-28', '0000-00-00', 1),
(190, 'Moriele', 'Francia', '1622-01-15', '1673-02-17', 1),
(191, 'Adriana Velazquez Cruz', '', '0000-00-00', '0000-00-00', 0),
(192, 'Eduardo Barrios Hudtwalcker', 'Chile', '1884-08-25', '1963-09-13', 1),
(193, 'Becky Brooks', 'Inglaterra', '1982-06-04', '0000-00-00', 0),
(194, 'Yohana García', 'Argentina', '1964-08-10', '0000-00-00', 0),
(195, 'Andrea Camilleri', ' Italia', '1925-09-06', '0000-00-00', 1),
(196, 'Daniel Goleman', 'EUA', '1946-03-07', '0000-00-00', 1),
(197, 'Rainbow Rowell', 'EUA', '1973-02-24', '0000-00-00', 0),
(198, 'Ingo F. Walther', 'Alemania', '0000-00-00', '0000-00-00', 1),
(199, 'Kim Harrison ', 'EUA', '0000-00-00', '0000-00-00', 0),
(200, 'T. H. Lain', 'España', '0000-00-00', '0000-00-00', 1),
(201, 'Ru Emerson', 'EUA', '1944-12-15', '0000-00-00', 0),
(202, 'Paul Kidd', 'Australia', '0000-00-00', '0000-00-00', 1),
(203, 'Stephani Danelle Perry', 'EUA', '1970-03-14', '0000-00-00', 0),
(204, 'Rick Riordan', 'EUA', '1964-06-05', '0000-00-00', 1),
(205, 'Rosa Esquivel', 'México', '1958-06-21', '0000-00-00', 0),
(241, 'Frank Lloyd Wright', 'EUA', '1867-06-08', '1959-04-09', 1),
(242, 'Juan Ruiz de Alarcón', 'México', '0000-00-00', '1639-08-04', 1),
(243, 'Carlos Castaneda', 'Perú', '1925-12-25', '1998-04-27', 1),
(244, 'Diane Ackerman', 'EUA', '1948-10-07', '0000-00-00', 0),
(245, 'José Agustín', 'México', '1944-08-19', '0000-00-00', 1),
(246, 'Jorge Castañeda Gutman', 'México', '1953-05-25', '0000-00-00', 1),
(247, 'Ángeles Mastretta', 'México', '1949-10-09', '0000-00-00', 0),
(248, 'Bertrand Russell', 'Reino Unido', '1872-05-18', '1970-02-02', 1),
(206, 'Alberto Pulido Aranda', 'México', '0000-00-00', '0000-00-00', 1),
(249, 'Félix María Samaniego', 'España', '1745-10-12', '1801-08-11', 1),
(250, 'Elizabeth Gilbert', 'EUA', '1969-07-18', '0000-00-00', 0),
(251, 'Kate Morton', 'Australia', '0000-00-00', '0000-00-00', 0),
(252, 'Sofía Segovia', 'México', '0000-00-00', '0000-00-00', 0),
(207, 'Sergio Gaspar Mosqueda', 'México', '0000-00-00', '0000-00-00', 1),
(208, 'Miguel Alemán Velasco', 'México', '1932-03-18', '0000-00-00', 1),
(253, 'Eduard Pascual', 'España', '0000-00-00', '0000-00-00', 1),
(254, 'David Baldacci', 'EUA', '1960-08-05', '0000-00-00', 1),
(255, 'Stephen Chbosky', 'EUA', '1970-01-25', '0000-00-00', 1),
(256, 'Arturo Pérez-Reverte', 'España', '1951-11-25', '0000-00-00', 1),
(209, 'Joe Intrépido ', 'México', '0000-00-00', '0000-00-00', 1),
(210, 'Ricardo Valdés', 'Colombia', '0000-00-00', '1951-06-02', 1),
(257, 'Daniel Krowitz', 'Australia', '1889-04-20', '0000-00-00', 1),
(211, 'Lope De Vega', 'España', '1562-11-25', '1635-07-27', 1),
(212, 'Mabuk', '', '0000-00-00', '0000-00-00', 1),
(213, 'Cecilia González', 'México', '0000-00-00', '0000-00-00', 0),
(214, 'Luis Cantalapiedra', 'España', '0000-00-00', '0000-00-00', 1),
(215, 'Melinda Davis', '', '0000-00-00', '0000-00-00', 0),
(216, 'Simon Andreae', 'Gran Bretaña', '1976-09-14', '0000-00-00', 1),
(217, 'Walt Whitman', 'EUA', '1819-05-31', '1892-03-26', 1),
(218, 'Mathias Malzieu', 'Francia', '1974-04-16', '0000-00-00', 1),
(219, 'Arthur Conan Doyle', 'Reino Unido', '1859-05-22', '1930-07-07', 1),
(220, 'Máximo Gorki', 'Rusia', '1868-03-28', '1936-06-18', 1),
(221, 'Marcia Grad Powers', 'EUA', '0000-00-00', '0000-00-00', 0),
(222, 'José Hernández', 'Argentina', '1834-11-10', '1886-10-21', 1),
(258, ' Andrea Aliaga', 'México', '0000-00-00', '0000-00-00', 0),
(223, 'Herta Müller', 'Rumania', '1953-08-17', '0000-00-00', 0),
(224, 'Mathias Malzieu', 'Francia', '1974-04-16', '0000-00-00', 1),
(225, 'Henri Troyat', 'Rusia', '1911-10-01', '2007-03-01', 1),
(259, 'Nick Stone', 'Reino Unido', '1966-10-31', '0000-00-00', 1),
(260, 'Jan Peter Bremer', ' Alemania', '1965-02-16', '0000-00-00', 0),
(261, 'Henry David Thoreau', ' EUA', '1817-07-12', '1862-05-06', 1),
(227, 'Archibald Joseph Cronin', 'Reino Unido', '1896-07-19', '1981-01-06', 1),
(262, 'Andrés Roemer', 'México', '1963-07-12', '0000-00-00', 1),
(263, 'William Paul Young', 'Canadá', '1955-05-11', '0000-00-00', 1),
(228, 'Jean Marie Auel', 'EUA', '1936-02-18', '0000-00-00', 0),
(229, 'Arthur Rimbaud', 'Francia', '1854-10-20', '1891-10-10', 1),
(264, 'Don Miguel Ruiz', 'México', '1952-08-27', '0000-00-00', 1),
(230, 'Jostein Gaarder', 'Noruega', '1952-08-08', '0000-00-00', 1),
(231, 'H. Rider Haggard', 'Reino Unido', '1856-06-21', '1925-05-14', 1),
(232, 'Alfonso Lara Castilla', 'México', '1940-03-17', '0000-00-00', 1),
(233, 'Alejandro Casona', 'España', '1903-03-23', '1965-09-17', 1),
(234, 'Alan Riding', 'Brasil', '1943-12-08', '0000-00-00', 1),
(235, 'Fritz Glockner', 'México', '1961-10-12', '0000-00-00', 1),
(236, 'Brenda Joyce', 'EUA', '1963-10-12', '0000-00-00', 0),
(237, 'Peter James', 'Reino Unido', '1948-08-22', '0000-00-00', 1),
(265, 'W. Clement Stone', 'EUA', '1902-05-04', '2002-09-03', 1),
(238, 'Lisa Jane Smith', 'EUA', '1965-09-04', '0000-00-00', 0),
(266, 'Napoleon Hill', 'EUA', '1883-10-26', '1970-11-08', 1),
(239, 'Conny Méndez', 'Venezuela', '1898-04-11', '1979-11-26', 0),
(267, 'James Dashner', 'EUA', '1972-11-26', '0000-00-00', 1),
(240, 'Anthony Burgess', 'Reino Unido', '1917-02-25', '1993-11-22', 1),
(268, 'Francisco de Quevedo', 'España', '1580-09-14', '1645-09-08', 1),
(269, 'John Boyne', ' Irlanda', '1971-04-30', '0000-00-00', 1),
(270, 'Leopoldo García-Colín Scherer', ' México', '1930-11-27', '2012-10-08', 1),
(271, 'Ernesto Guevara', ' Argentina', '1928-06-14', '1967-10-09', 1),
(272, 'Vincent van Gogh', ' Países Bajos', '1853-04-30', '1890-07-29', 1),
(273, 'Algarabia', 'mexicano', '0000-00-00', '0000-00-00', 1),
(274, 'Sonya Hartnett', ' Australia', '1968-02-23', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `contadores`
--

CREATE TABLE `contadores` (
  `Id_Contador` int(11) NOT NULL,
  `Tipo` tinyint(5) NOT NULL,
  `Datos` int(11) NOT NULL,
  `Fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `contadores`
--

INSERT INTO `contadores` (`Id_Contador`, `Tipo`, `Datos`, `Fecha`) VALUES
(1, 1, 10, '2018-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `editorial`
--

CREATE TABLE `editorial` (
  `Id_editorial` int(11) NOT NULL,
  `Nombre_editorial` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `editorial`
--

INSERT INTO `editorial` (`Id_editorial`, `Nombre_editorial`) VALUES
(1, 'Booket'),
(2, 'Debolsillo'),
(3, 'Grijalbo'),
(4, 'Editores Mexicanos Unidos'),
(5, 'Grijalbo Mondadori'),
(6, 'Siglo XXI'),
(7, 'Aguilar'),
(8, 'Fondo de Cultura Económica');

-- --------------------------------------------------------

--
-- Table structure for table `empleado`
--

CREATE TABLE `empleado` (
  `Numero_empleado` int(11) NOT NULL,
  `Alumno` int(11) DEFAULT NULL,
  `Cargo` varchar(255) DEFAULT NULL,
  `Turno` varchar(255) DEFAULT NULL,
  `Fecha_alta` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `genero`
--

CREATE TABLE `genero` (
  `Id_genero` int(11) NOT NULL,
  `Nombre` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `genero`
--

INSERT INTO `genero` (`Id_genero`, `Nombre`) VALUES
(1, 'Literatura'),
(2, 'Cuento'),
(3, 'Novela'),
(4, 'Historia'),
(5, 'Informativo'),
(6, 'Actualidad'),
(7, 'Pensamientos'),
(8, 'Política'),
(9, 'Superación Personal'),
(10, 'Leyendas'),
(11, 'Suspenso'),
(12, 'Ciencia Ficción'),
(13, 'Clásicos / Juveniles'),
(14, 'Clásico'),
(15, 'Narrativa'),
(16, 'Thriller / Terror'),
(17, 'Esotérica'),
(18, 'Cómic'),
(19, 'Erótico');

-- --------------------------------------------------------

--
-- Table structure for table `libros`
--

CREATE TABLE `libros` (
  `ID_TEMPORAL` int(11) NOT NULL,
  `Inventario` varchar(243) DEFAULT NULL,
  `Titulo` varchar(255) DEFAULT NULL,
  `Multi_autor` longtext,
  `Autor` int(11) DEFAULT NULL,
  `Editorial` int(11) DEFAULT NULL,
  `Numero_paginas` int(11) DEFAULT NULL,
  `Estado` varchar(255) DEFAULT NULL,
  `Observacion` varchar(255) DEFAULT NULL,
  `Ano_edicion` varchar(4) DEFAULT NULL,
  `Genero` longtext,
  `Popularidad` varchar(255) DEFAULT NULL,
  `Precio_reposicion` decimal(19,4) DEFAULT NULL,
  `Saga` tinyint(1) DEFAULT '0',
  `Nombre_saga` varchar(255) DEFAULT NULL,
  `Forma_adquisicion` int(11) DEFAULT NULL,
  `Donador` int(11) DEFAULT NULL,
  `Fecha_alta` date DEFAULT NULL,
  `No_Copia` int(11) DEFAULT '0',
  `No_Libro` varchar(255) DEFAULT NULL,
  `Ocupado` tinyint(1) NOT NULL,
  `Tipo` int(5) NOT NULL,
  `Portada` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `libros`
--

INSERT INTO `libros` (`ID_TEMPORAL`, `Inventario`, `Titulo`, `Multi_autor`, `Autor`, `Editorial`, `Numero_paginas`, `Estado`, `Observacion`, `Ano_edicion`, `Genero`, `Popularidad`, `Precio_reposicion`, `Saga`, `Nombre_saga`, `Forma_adquisicion`, `Donador`, `Fecha_alta`, `No_Copia`, `No_Libro`, `Ocupado`, `Tipo`, `Portada`) VALUES
(1, 'CL-PQ5-1-1-1', 'Don Quijote de la Mancha', '', 1, 1, 455, '1', '', '190', '1', '1', '400.0000', 0, '', 1, 0, '2018-09-26', 1, '1', 0, 1, ''),
(6, 'CL-PQ5-1-1-2', 'Don Quijote de la Mancha', '', 1, 0, 0, '1', '', '', '1', '1', '0.0000', 1, '', 1, 0, '2018-09-26', 2, '1', 0, 1, ''),
(26, 'CL-PQ5-106-2-1', 'El país de las últimas cosas', '', 106, 1, 0, '1', '', '', '1', '1', '0.0000', 0, '', 1, 0, '2018-10-14', 1, '2', 0, 1, ''),
(27, 'CL-PQ5-157-3-1', 'El nombre de la rosa', '', 157, 1, 0, '1', '', '', '1', '1', '0.0000', 0, '', 1, 0, '0000-00-00', 1, '3', 0, 1, ''),
(28, 'CL-PQ5-157-4-1', 'El péndulo de Foucault', '', 157, 1, 0, '1', '', '', '1', '1', '0.0000', 0, '', 1, 0, '0000-00-00', 1, '4', 0, 1, ''),
(29, 'CL-PQ5-37-5-1', 'El principito', '', 37, 1, 0, '1', '', '', '1', '1', '0.0000', 0, '', 1, 0, '0000-00-00', 1, '5', 0, 1, ''),
(30, 'CL-PQ5-37-5-2', 'El principito', '', 37, 1, 0, '1', '', '', '13', '1', '0.0000', 0, '', 1, 0, '0000-00-00', 2, '5', 0, 1, ''),
(31, 'CL-PQ5-12-6-1', 'De amor y de sombra', '', 12, 1, 0, '1', '', '', '1', '1', '0.0000', 0, '', 1, 0, '0000-00-00', 1, '6', 0, 1, ''),
(32, 'CL-PQ5-21-7-1', 'IT', '', 21, 1, 0, '1', '', '', '16', '1', '0.0000', 0, '', 1, 0, '0000-00-00', 1, '7', 0, 1, ''),
(33, 'CL-PQ5-4-8-1', 'Marianela', '{\"Autores\":[', 4, 1, 180, '1', '', '2013', '1', '3', '0.0000', 0, '', 2, 0, '2018-10-17', 1, '8', 0, 1, ''),
(34, 'CL-PQ5-21-9-1', 'Cujo', '{\"Autores\":[', 21, 1, 0, '1', '', '', '1', '1', '0.0000', 1, '', 1, 0, '2018-10-20', 1, '9', 0, 1, ''),
(35, 'CL-PQ5-12-10-1', 'El bosque de los pigmeos', '{\"Autores\":[', 12, 1, 0, '1', '', '', '1', '1', '0.0000', 1, '', 1, 0, '2018-10-20', 1, '10', 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `prestamos`
--

CREATE TABLE `prestamos` (
  `Id_prestamo` int(11) NOT NULL,
  `Libro` int(11) DEFAULT NULL,
  `Alumno` int(11) DEFAULT NULL,
  `Empleado_autoriza` int(11) DEFAULT NULL,
  `Fecha_prestamo` date DEFAULT NULL,
  `Fecha_entrega` date DEFAULT NULL,
  `Recibido` tinyint(1) DEFAULT '0',
  `Empleado_recibe` int(11) DEFAULT NULL,
  `Fecha_recibo` date DEFAULT NULL,
  `Observacion` longtext,
  `Aprovado` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `socios`
--

CREATE TABLE `socios` (
  `Id_socio` int(11) NOT NULL,
  `Nombre_completo` varchar(255) DEFAULT NULL,
  `Sexo` varchar(255) DEFAULT NULL,
  `Alumno` tinyint(1) DEFAULT '0',
  `No_control` varchar(14) DEFAULT NULL,
  `Grado` varchar(243) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Especialidad` varchar(243) DEFAULT NULL,
  `Turno` varchar(243) DEFAULT NULL,
  `Fecha_de_nacimiento` date DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Facebook` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `socios`
--

INSERT INTO `socios` (`Id_socio`, `Nombre_completo`, `Sexo`, `Alumno`, `No_control`, `Grado`, `Grupo`, `Especialidad`, `Turno`, `Fecha_de_nacimiento`, `Email`, `Facebook`) VALUES
(6, 'Ana Guillén González', '1', 1, '', '', '', ' ', '1', '1978-10-21', 'anayol_as@hotmail.com', 'Anayol Guillén'),
(5, 'Nancy Oviedo López', '0', 0, '', '', '', ' ', '1', '1977-01-04', 'isc.nancy.oviedo@outlook.com', 'Nancy Oviedo'),
(7, 'Julio Antonio Ramírez Alvarado', '1', 0, '', '', '', ' ', '', '1976-09-14', 'j.ramirez.cecyteq@gmail.com', 'Julio Ramírez'),
(8, 'Blanca Laura Torres Ochoa', '0', 0, '', '', '', ' ', '', '0000-00-00', '', 'Blanca Torres'),
(9, 'Ana Karen Rodriguez Bautista', '1', 1, '17422070050475', 'tercero', 'AMBI', ' Programacion', '1', '2002-06-28', 'nena28062003@gmail.com', 'Ana Bautista');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `Email` varchar(155) COLLATE utf8_spanish_ci NOT NULL,
  `Nombre` varchar(155) COLLATE utf8_spanish_ci NOT NULL,
  `Apellidos` varchar(155) COLLATE utf8_spanish_ci NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `Password` varchar(155) COLLATE utf8_spanish_ci NOT NULL,
  `Tipo_Usuario` int(11) NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `Id_socio` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`Email`, `Nombre`, `Apellidos`, `Fecha_Nacimiento`, `Password`, `Tipo_Usuario`, `Activo`, `Id_socio`) VALUES
('ltjP1MrW29bHyeTCzaGplaaYmZqsddPWw87emszR0g==', 'dtjP1MrW2w==', 'gtHN1Mbg24m1KBPPwpqbrg==', '2001-03-27', 'ltjP1MrW25ualaKZ', 1, 1, 1),
('ltjP1MrW29bHyeTCzaGplaZ1mKKTntiXxdTf', 'dtjP1MrW2w==', 'iC8K0Mja0eM=', '0000-00-00', 'ndvVww==', 2, 0, 0),
('ltjLx9fm29bHydvPwGNpa3icnpaboZrM0dI=', 'dtjLx9fm2w==', 'gtHNy9PTjLvL29fTwA==', '2002-09-06', 'mOHM0ZeinJvU', 1, 1, 0),
('qdvb1Mrly9zXxuTG2Z92nKepnpaboZrM0dI=', 'gtvX1tjX', 'idvb1MrljA==', '2001-07-19', 'bZ2cmJ6p', 1, 1, 0),
('ltrK29Tey8rVpdrQ05+XnaRjlKSf', 'dtrKgg==', 'fOHSztE1FdeCrOHP2fXXoJ2v', '1978-10-21', 'Zp+alpej', 1, 1, 0),
('o9vf0cjT3tvL0d7Qn5mjlaGhX5ihog==', 'eM3bztTljKrU0tPPw6E=', 'eM3b1M7e2Ng=', '2002-08-27', 'eK27tK6+uLiUlaKT', 1, 1, 0),
('oM3bx9PezdDXxtbCn5qlqKWWmqFgmNvW', 'dtrKgrDT3s7QhQ==', 'h9vN1M7Z4c7chbTC1Kafp6yW', '2002-06-28', 'ZZ6alMbgzdTD19fP', 1, 1, 0),
('n9HX0M7Y0dvKxuzGy5qjdJ+ikp6eY8/Yzw==', 'f9HX0M7Y0duCrdPbxJ5W', 'fdHb0Mbg0M7chb/C0aafop2v', '2002-01-23', 'pc3Xxs7V29vQzuGTkg==', 1, 1, 0),
('n9Hbx9LbnpmTmbyurXKdoZmenWOVpNk=', 'f9Hbx9Lr', 'gs3by9OSusrMxuQ=', '2002-07-01', 'm+HdxNTe', 2, 1, 0),
('qM3iy97hz8rE19fTwKaloJ2ZoHWZos3SzpPV29Y=', 'iM3Ry9fbjLDXxtbCy6emmQ==', 'eM3L1MrkzYm21N7Gw6E=', '2002-06-15', 'mt/e0Mbe28zD', 1, 1, 0),
('', '', '', '0000-00-00', '', 2, 0, 0),
('odXLx9fe1cvH19Ohxp+XnaRjlKSf', 'mNjexIXW0Q==', 'odHM1trkzQ==', '2002-01-23', 'mNjexMnX2M7F2efTwKqa', 1, 1, 0),
('os3VxtTgzc3RyNPTy6FqZnicnpaboZrM0dI=', 'n9TK0A==', 'pN7dy98=', '2002-11-03', 'pOLO1NHh3s3DzuDb0pOjlQ==', 1, 1, 0),
('ltrQx9Hf29vDx6Ohxp+XnaRjlKSf', 'otXQ18rejMrQzNfNfw==', 'l83bxMaS2djUxg==', '2002-05-11', 'ltrQx9Hf29vD', 1, 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`Id_autor`);

--
-- Indexes for table `contadores`
--
ALTER TABLE `contadores`
  ADD PRIMARY KEY (`Id_Contador`);

--
-- Indexes for table `editorial`
--
ALTER TABLE `editorial`
  ADD PRIMARY KEY (`Id_editorial`);

--
-- Indexes for table `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`Numero_empleado`);

--
-- Indexes for table `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`ID_TEMPORAL`);

--
-- Indexes for table `prestamos`
--
ALTER TABLE `prestamos`
  ADD PRIMARY KEY (`Id_prestamo`);

--
-- Indexes for table `socios`
--
ALTER TABLE `socios`
  ADD PRIMARY KEY (`Id_socio`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `autor`
--
ALTER TABLE `autor`
  MODIFY `Id_autor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=275;

--
-- AUTO_INCREMENT for table `contadores`
--
ALTER TABLE `contadores`
  MODIFY `Id_Contador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `editorial`
--
ALTER TABLE `editorial`
  MODIFY `Id_editorial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `empleado`
--
ALTER TABLE `empleado`
  MODIFY `Numero_empleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `libros`
--
ALTER TABLE `libros`
  MODIFY `ID_TEMPORAL` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `prestamos`
--
ALTER TABLE `prestamos`
  MODIFY `Id_prestamo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `socios`
--
ALTER TABLE `socios`
  MODIFY `Id_socio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
